Courses App - Solution Code
================================

Solution code for the Android Basics with Compose: Build a grid list practice problem set.


Introduction
------------
The Courses app consists of a scrollable grid of course topics.


All photos by Romain Guy. All photos are licensed under CC0 1.0 Universal: https://creativecommons.org/publicdomain/zero/1.0/
