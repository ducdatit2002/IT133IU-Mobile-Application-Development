package com.botsheloramela.calculatorapp

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.botsheloramela.calculatorapp.ui.theme.CalculatorAppTheme

class HistoryActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedPreferences = getSharedPreferences("calculator_history", Context.MODE_PRIVATE)
        setContent {
            CalculatorAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    HistoryScreen(sharedPreferences, onBack = { finish() })
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(
    sharedPreferences: android.content.SharedPreferences,
    onBack: () -> Unit
) {
    var history by remember { mutableStateOf(sharedPreferences.getString("history", "") ?: "") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("History", fontSize = 32.sp, modifier = Modifier.padding(bottom = 16.dp))

        Box(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
            Text(history.ifEmpty { "No history yet" }, fontSize = 20.sp)
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(
                onClick = {
                    sharedPreferences.edit().putString("history", "").apply()
                    history = ""
                },
                modifier = Modifier.padding(8.dp)
            ) {
                Text("Clear History", fontSize = 18.sp)
            }

            Button(
                onClick = onBack,
                modifier = Modifier.padding(8.dp)
            ) {
                Text("Back", fontSize = 18.sp)
            }
        }
    }
}
