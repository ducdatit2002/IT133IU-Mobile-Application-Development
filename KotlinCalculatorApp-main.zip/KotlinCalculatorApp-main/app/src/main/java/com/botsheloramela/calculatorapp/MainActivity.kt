package com.botsheloramela.calculatorapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.botsheloramela.calculatorapp.ui.theme.CalculatorAppTheme
import org.mariuszgromada.math.mxparser.Expression

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CalculatorAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CalculatorScreen(this)
                }
            }
        }
    }
}

@Composable
fun CalculatorScreen(context: Context) {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    val sharedPreferences = context.getSharedPreferences("calculator_history", Context.MODE_PRIVATE)

    val buttonRows = listOf(
        listOf("C", "(", ")", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "-"),
        listOf("1", "2", "3", "+"),
        listOf("AC", "0", ".", "=")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Expression display
        Text(
            text = expression,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(top = 16.dp),
            style = TextStyle(fontSize = 32.sp, textAlign = TextAlign.End)
        )

        // Result display
        Text(
            text = result,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 8.dp),
            style = TextStyle(fontSize = 48.sp, textAlign = TextAlign.End)
        )

        // Spacer to push buttons to the bottom
        Spacer(modifier = Modifier.weight(1f))

        // Buttons Grid
        buttonRows.forEach { row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row.forEach { text ->
                    CalculatorButton(
                        text = text,
                        modifier = Modifier.size(90.dp),
                        onClick = {
                            when (text) {
                                "C" -> expression = expression.dropLast(1)
                                "AC" -> {
                                    expression = ""
                                    result = ""
                                }
                                "=" -> {
                                    val res = solveExpression(expression)
                                    result = res
                                    saveHistory(sharedPreferences, "$expression = $res")
                                }
                                else -> expression += text
                            }
                        }
                    )
                }
            }
        }

        // History Button
        Button(
            onClick = {
                context.startActivity(Intent(context, HistoryActivity::class.java))
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        ) {
            Text("History", fontSize = 20.sp)
        }
    }
}

fun solveExpression(expression: String): String {
    return try {
        val modifiedExpression = expression.replace("×", "*").replace("÷", "/")
        val result = Expression(modifiedExpression).calculate()
        if (result.isNaN()) "Error" else result.toString().trimEnd('0').trimEnd('.')
    } catch (e: Exception) {
        "Error"
    }
}

fun saveHistory(sharedPreferences: android.content.SharedPreferences, entry: String) {
    val history = sharedPreferences.getString("history", "") ?: ""
    sharedPreferences.edit().putString("history", "$entry\n$history").apply()
}

@Composable
fun CalculatorButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val backgroundColor = when (text) {
        "C", "AC" -> MaterialTheme.colorScheme.error
        "÷", "×", "-", "+", "=" -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondary
    }

    Button(
        onClick = onClick,
        modifier = modifier
            .padding(4.dp)
            .clip(CircleShape),
        colors = ButtonDefaults.buttonColors(containerColor = backgroundColor)
    ) {
        Text(text = text, style = TextStyle(fontSize = 28.sp))
    }
}
