package dev.codeninja.artspace.ui.theme

import androidx.compose.ui.graphics.Color

val Teal200 = Color(0xFF03DAC5)
val Blue200 = Color(0xFF3A96DD)
val Blue500 = Color(0xFF247AE4)